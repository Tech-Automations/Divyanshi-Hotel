﻿$(document).ready(function () {



    $('a[href="#"]').attr('href', 'javascript:void(0)');


    $(".navbox > ul > li > a").each(function () {
        if (this.href == window.location.href) {
            $(this).addClass("navactive");
        }
    });



    $(window).scroll(function () {
        if ($(this).scrollTop() > 200) {
            $('.scrollToTop').fadeIn();
        } else {
            $('.scrollToTop').fadeOut();
        }
    });

    $('.scrollToTop').click(function () {
        $('html, body').animate({ scrollTop: 0 }, 800);
        return false;
    });

    $(window).scroll(function () {
        if ($(this).scrollTop() > 50) {
            $('body').addClass('stickyheader');
        } else {
            $('body').removeClass('stickyheader');
        }
    });

 




});
